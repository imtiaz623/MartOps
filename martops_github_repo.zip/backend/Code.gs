/** MartOps MASTER backend (multi-tenant). Deploy ONCE: Execute as Me, Access: Anyone.
 *  Setup: paste in a Google Sheet's Apps Script, set timezone Asia/Karachi (Project Settings), run setup().
 *  Super Admin: open 'Companies' tab, set status = ACTIVE after verifying TID (validUntil auto-fills). */
const TZ='Asia/Karachi',DAY=864e5,MIN=6e4,PORTAL='https://martops.vercel.app';
const MAX_BR=10,MAX_WIFI=4,MAX_TEAM=15,STALE=15*MIN,ALERT_MIN=15,P=PropertiesService.getScriptProperties();
const T={
 Companies:['id','code','slug','name','ownerName','phone','wa','plan','status','trialEnd','validUntil','tid','backupUrl','created'],
 Users:['company','userId','name','role','pass','salt','branch','captain','phone','active'],
 Branches:['company','id','name','city','wifi','shift'],
 Duties:['company','id','staff','captain','branch','aisle','task','day','done'],
 Presence:['company','staff','branch','status','lastSeen','outSince','alerted','ssid'],
 Logs:['company','branch','city','staff','captain','left','back','minutes'],
 Attendance:['company','day','staff','branch','firstSeen','late']
};
function setup(){
 Object.keys(T).forEach(sh);
 if(!P.getProperty('SECRET'))P.setProperty('SECRET',Utilities.getUuid()+Utilities.getUuid());
 ScriptApp.getProjectTriggers().forEach(t=>ScriptApp.deleteTrigger(t));
 ScriptApp.newTrigger('nightlyReport').timeBased().everyDays(1).atHour(23).create();
 ScriptApp.newTrigger('checkStale').timeBased().everyMinutes(5).create();
}
// ---------- sheet helpers ----------
function sh(n){const ss=SpreadsheetApp.getActive();let s=ss.getSheetByName(n);if(!s){s=ss.insertSheet(n);s.appendRow(T[n]);}return s;}
function all(n){const v=sh(n).getDataRange().getValues(),h=v[0];return v.slice(1).map((r,i)=>{const o={_row:i+2};h.forEach((k,j)=>o[k]=r[j]);return o;});}
function add(n,o){sh(n).appendRow(T[n].map(k=>o[k]===undefined?'':o[k]));}
function upd(n,row,p){const s=sh(n);Object.keys(p).forEach(k=>s.getRange(row,T[n].indexOf(k)+1).setValue(p[k]));}
function setP(cid,staff,p){const r=all('Presence').find(x=>x.company===cid&&x.staff===staff);
 if(r)upd('Presence',r._row,p);else add('Presence',{company:cid,staff,...p});}
// ---------- utils ----------
const out=o=>ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
const hash=(p,s)=>'h:'+Utilities.base64Encode(Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,s+p));
const dayKey=ms=>Number(Utilities.formatDate(new Date(ms),TZ,'yyyyMMdd'));
const digits=s=>String(s||'').replace(/\D/g,'');
const wf=s=>String(s||'').split('|').filter(Boolean);
const fmtShift=m=>{m=Number(m)||540;return String(Math.floor(m/60)).padStart(2,'0')+':'+String(m%60).padStart(2,'0');};
function sign(p){const b=Utilities.base64EncodeWebSafe(JSON.stringify(p));
 return b+'.'+Utilities.base64EncodeWebSafe(Utilities.computeHmacSha256Signature(b,P.getProperty('SECRET')));}
function verify(t){const [b,s]=String(t||'').split('.');if(!b||!s)return null;
 if(Utilities.base64EncodeWebSafe(Utilities.computeHmacSha256Signature(b,P.getProperty('SECRET')))!==s)return null;
 const p=JSON.parse(Utilities.newBlob(Utilities.base64DecodeWebSafe(b)).getDataAsString());return p.exp>Date.now()?p:null;}
// ---------- entry ----------
function doGet(e){const p=e.parameter||{};return out(p.slug?companyInfo(p):{ok:true,service:'martops'});}
function doPost(e){let d;try{d=JSON.parse(e.postData.contents);}catch(x){return out({ok:false,error:'bad_json'});}
 try{return out(route(d));}catch(x){return out({ok:false,error:String(x.message||x)});}}
const PUB={register:d=>register(d),login:d=>login(d),companyInfo:d=>companyInfo(d)};
function route(d){
 if(PUB[d.action])return PUB[d.action](d);
 const u=verify(d.token);if(!u)return{ok:false,error:'auth'};
 const c=all('Companies').find(x=>x.id===u.c);if(!c)return{ok:false,error:'company_missing'};
 const s=subState(c);
 if(d.action==='sub')return{ok:true,...s};
 if(d.action==='pay'){if(u.r!=='owner')return{ok:false,error:'forbidden'};
  upd('Companies',c._row,{plan:d.plan==='YEARLY'?'YEARLY':'MONTHLY',tid:String(d.tid||''),status:'PENDING'});return{ok:true,status:'PENDING'};}
 if(!s.allowed)return{ok:false,error:'subscription_inactive',status:s.status};
 const A=ACT[d.action];if(!A)return{ok:false,error:'unknown_action'};
 if(A[0].indexOf(u.r)<0)return{ok:false,error:'forbidden'};
 return A[1](c,u,d);
}
// ---------- onboarding / auth ----------
function register(d){
 const pw=String(d.password||'');if(!d.companyName||pw.length<6)throw new Error('companyName and password (6+ chars) required');
 const cs=all('Companies');let base=String(d.companyName).toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'')||'store',slug=base,n=1;
 while(cs.some(c=>c.slug===slug))slug=base+'-'+(++n);
 let code;do{code=(base.replace(/[^a-z]/g,'').slice(0,3).toUpperCase().padEnd(3,'X'))+Math.floor(1000+Math.random()*9000);}while(cs.some(c=>c.code===code));
 const id='C'+Utilities.getUuid().replace(/-/g,'').slice(0,7),salt=Utilities.getUuid();
 add('Companies',{id,code,slug,name:d.companyName,ownerName:d.ownerName||'',phone:digits(d.phone),wa:digits(d.wa||d.phone),plan:'TRIAL',status:'TRIAL',trialEnd:Date.now()+14*DAY,created:Date.now()});
 add('Users',{company:id,userId:'owner',name:d.ownerName||'Owner',role:'owner',pass:hash(pw,salt),salt,active:1});
 return{ok:true,code,slug,portalUrl:PORTAL+'/?company='+slug,token:sign({c:id,u:'owner',r:'owner',exp:Date.now()+30*DAY})};
}
function companyInfo(d){const k=String(d.slug||d.company||'').toLowerCase();
 const c=all('Companies').find(x=>x.slug===k||String(x.code).toLowerCase()===k);
 return c?{ok:true,name:c.name,code:c.code,slug:c.slug}:{ok:false,error:'company_not_found'};}
function login(d){
 const k=String(d.company||'').toLowerCase(),c=all('Companies').find(x=>x.slug===k||String(x.code).toLowerCase()===k);
 if(!c)return{ok:false,error:'company_not_found'};
 const u=all('Users').find(x=>x.company===c.id&&String(x.userId).toLowerCase()===String(d.userId||'').toLowerCase()&&Number(x.active)!==0);
 if(!u||u.pass!==hash(String(d.password||''),u.salt))return{ok:false,error:'bad_credentials'};
 return{ok:true,role:u.role,name:u.name,userId:u.userId,company:{code:c.code,name:c.name,slug:c.slug},
  token:sign({c:c.id,u:u.userId,r:u.role,exp:Date.now()+(u.role==='staff'?90:30)*DAY})};
}
function subState(c){
 const now=Date.now(),vu=c.validUntil?new Date(c.validUntil).getTime():0;
 if(c.status==='ACTIVE'){
  if(!vu){const v=now+(c.plan==='YEARLY'?365:30)*DAY;upd('Companies',c._row,{validUntil:new Date(v)});return{allowed:true,status:'ACTIVE',validUntil:v};}
  return vu>now?{allowed:true,status:'ACTIVE',validUntil:vu}:{allowed:false,status:'EXPIRED'};}
 if(c.status==='TRIAL'&&Number(c.trialEnd)>now)return{allowed:true,status:'TRIAL',trialEnd:Number(c.trialEnd)};
 return{allowed:false,status:c.status==='PENDING'?'PENDING':'EXPIRED'};
}
// ---------- presence ----------
function view(p,now){
 if(!p)return{status:'NO_DATA',outMin:0,out:0,lastSeen:0};
 let st=p.status,o=Number(p.outSince)||0;
 if(st==='CONNECTED'&&now-Number(p.lastSeen)>STALE){st='NO_SIGNAL';o=Number(p.lastSeen);}
 return{status:st,out:o,outMin:o?Math.floor((now-o)/MIN):0,lastSeen:Number(p.lastSeen)||0,ssid:p.ssid||''};
}
function heartbeat(c,u,d){
 const now=Date.now(),us=all('Users'),usr=us.find(x=>x.company===c.id&&x.userId===u.u);
 const br=all('Branches').find(b=>b.company===c.id&&b.id===usr.branch)||{};
 const p=all('Presence').find(x=>x.company===c.id&&x.staff===u.u);
 if(d.connected){
  const left=Number(d.leftAt)||Number(p&&p.outSince)||0,mins=left?Math.round((now-left)/MIN):0;
  if(mins>=1){const cap=us.find(x=>x.company===c.id&&x.userId===usr.captain);
   const row={company:c.id,branch:br.name,city:br.city,staff:usr.name,captain:cap?cap.name:'',left,back:now,minutes:mins};
   add('Logs',row);backup(c,row);}
  setP(c.id,u.u,{branch:usr.branch,status:'CONNECTED',lastSeen:now,outSince:'',alerted:0,ssid:d.ssid||''});
  if(!p||p.status!=='CONNECTED'||dayKey(Number(p.lastSeen))!==dayKey(now))markAttendance(c,usr,br,now);
 }else{
  const o=Number(p&&p.outSince)||Number(d.leftAt)||now;let al=Number(p&&p.alerted)||0;
  if(now-o>ALERT_MIN*MIN&&!al){notifyCaptain(c,usr,br,Math.round((now-o)/MIN),us);al=1;}
  setP(c.id,u.u,{branch:usr.branch,status:'OUT',lastSeen:now,outSince:o,alerted:al,ssid:''});
 }
 return{ok:true};
}
function markAttendance(c,usr,br,now){const day=dayKey(now);
 if(all('Attendance').some(a=>a.company===c.id&&Number(a.day)===day&&a.staff===usr.userId))return;
 const [h,m]=Utilities.formatDate(new Date(now),TZ,'H:m').split(':').map(Number);
 add('Attendance',{company:c.id,day,staff:usr.userId,branch:usr.branch,firstSeen:now,late:(h*60+m>(Number(br.shift)||540)+10)?1:0});}
function notifyCaptain(c,usr,br,min,us){const cap=us.find(x=>x.company===c.id&&x.userId===usr.captain);
 if(cap&&cap.phone)notify(cap.phone,`ALERT: ${usr.name} has been out of ${br.name} (${br.city}) for ${min} min.`);}
function checkStale(){const now=Date.now(),cs=all('Companies'),ok={},us=all('Users'),brs=all('Branches');
 cs.forEach(c=>ok[c.id]=subState(c).allowed);
 all('Presence').forEach(p=>{if(!ok[p.company])return;const v=view(p,now),c=cs.find(x=>x.id===p.company);
  if(v.status==='NO_SIGNAL')upd('Presence',p._row,{status:'OUT',outSince:v.out});
  if((v.status==='OUT'||v.status==='NO_SIGNAL')&&v.outMin>ALERT_MIN&&!Number(p.alerted)){
   const usr=us.find(x=>x.company===p.company&&x.userId===p.staff);
   if(usr)notifyCaptain(c,usr,brs.find(b=>b.id===usr.branch)||{},v.outMin,us);upd('Presence',p._row,{alerted:1});}});}
// ---------- owner ----------
function dashboard(c,u,d){
 const now=Date.now(),day=dayKey(now),pres=all('Presence').filter(p=>p.company===c.id);
 const branches=all('Branches').filter(b=>b.company===c.id).map(b=>({id:b.id,name:b.name,city:b.city,wifi:wf(b.wifi),shift:fmtShift(b.shift)}));
 const users=all('Users').filter(x=>x.company===c.id&&x.role!=='owner'&&Number(x.active)!==0)
  .map(x=>({userId:x.userId,name:x.name,role:x.role,branch:x.branch,captain:x.captain,phone:x.phone,...view(pres.find(p=>p.staff===x.userId),now)}));
 const logs=all('Logs').filter(l=>l.company===c.id).slice(-200).reverse();
 const att=all('Attendance').filter(a=>a.company===c.id&&Number(a.day)===day);
 const duties=all('Duties').filter(x=>x.company===c.id&&Number(x.day)===day);
 return{ok:true,company:{name:c.name,code:c.code,slug:c.slug,backupUrl:c.backupUrl||'',wa:String(c.wa||''),portalUrl:PORTAL+'/?company='+c.slug},sub:subState(c),branches,users,logs,att,duties};
}
function saveBranch(c,u,d){
 const list=all('Branches').filter(b=>b.company===c.id);
 const wifi=(d.wifi||[]).map(s=>String(s).trim()).filter(Boolean).slice(0,MAX_WIFI);
 if(!wifi.length)throw new Error('at_least_1_wifi');
 if(!d.name||!d.city)throw new Error('name and city required');
 const [h,m]=String(d.shift||'09:00').split(':').map(Number);
 const o={name:d.name,city:d.city,wifi:wifi.join('|'),shift:(h||0)*60+(m||0)};
 if(d.id){const b=list.find(x=>x.id===d.id);if(!b)throw new Error('not_found');upd('Branches',b._row,o);return{ok:true,id:b.id};}
 if(list.length>=MAX_BR)throw new Error('branch_limit_10');
 const id='B'+Utilities.getUuid().replace(/-/g,'').slice(0,6);add('Branches',{company:c.id,id,...o});return{ok:true,id};
}
function delBranch(c,u,d){const b=all('Branches').find(x=>x.company===c.id&&x.id===d.id);if(b)sh('Branches').deleteRow(b._row);return{ok:true};}
function setBackup(c,u,d){const url=String(d.url||'').trim();
 if(url&&url.indexOf('https://script.google.com/')!==0)throw new Error('invalid_script_url');
 upd('Companies',c._row,{backupUrl:url,wa:digits(d.wa)||c.wa});return{ok:true};}
function backup(c,row){if(!c.backupUrl)return;
 try{UrlFetch(c.backupUrl,{type:'log',row});}catch(e){}}
function UrlFetch(url,body){UrlFetchApp.fetch(url,{method:'post',contentType:'application/json',payload:JSON.stringify(body),muteHttpExceptions:true});}
// ---------- users ----------
function addUser(c,u,d){
 const us=all('Users').filter(x=>x.company===c.id);let role,branch,captain='';
 if(!d.name)throw new Error('name_required');
 if(u.r==='owner'){role='captain';branch=d.branch;
  if(!all('Branches').some(b=>b.company===c.id&&b.id===branch))throw new Error('branch_required');}
 else{role='staff';const me=us.find(x=>x.userId===u.u);branch=me.branch;captain=me.userId;
  if(us.filter(x=>x.captain===captain&&Number(x.active)!==0).length>=MAX_TEAM)throw new Error('team_full_15');}
 let id;do{id=(role==='captain'?'CP':'ST')+Math.floor(1000+Math.random()*9000);}while(us.some(x=>x.userId===id));
 const pin=String(Math.floor(100000+Math.random()*900000)),salt=Utilities.getUuid();
 add('Users',{company:c.id,userId:id,name:d.name,role,pass:hash(pin,salt),salt,branch,captain,phone:digits(d.phone),active:1});
 return{ok:true,userId:id,pin};
}
function manageUser(c,u,d){
 const t=all('Users').find(x=>x.company===c.id&&x.userId===d.userId&&x.role!=='owner');if(!t)throw new Error('not_found');
 if(u.r==='captain'&&t.captain!==u.u)throw new Error('forbidden');
 if(d.op==='remove'){upd('Users',t._row,{active:0});return{ok:true};}
 const pin=String(Math.floor(100000+Math.random()*900000)),salt=Utilities.getUuid();
 upd('Users',t._row,{pass:hash(pin,salt),salt});return{ok:true,pin};
}
// ---------- captain / staff ----------
function team(c,u,d){
 const now=Date.now(),day=dayKey(now),pres=all('Presence').filter(p=>p.company===c.id);
 const staff=all('Users').filter(x=>x.company===c.id&&x.captain===u.u&&Number(x.active)!==0)
  .map(x=>({userId:x.userId,name:x.name,phone:x.phone,...view(pres.find(p=>p.staff===x.userId),now)}));
 const duties=all('Duties').filter(x=>x.company===c.id&&x.captain===u.u&&Number(x.day)===day);
 return{ok:true,staff,duties};
}
function assignDuty(c,u,d){
 const st=all('Users').find(x=>x.company===c.id&&x.userId===d.staff&&x.captain===u.u);if(!st)throw new Error('staff_not_found');
 if(!d.aisle)throw new Error('aisle_required');
 add('Duties',{company:c.id,id:'D'+Utilities.getUuid().replace(/-/g,'').slice(0,6),staff:st.userId,captain:u.u,branch:st.branch,aisle:d.aisle,task:d.task||'',day:dayKey(Date.now()),done:0});
 return{ok:true};
}
function myDuties(c,u,d){return{ok:true,duties:all('Duties').filter(x=>x.company===c.id&&x.staff===u.u&&Number(x.day)===dayKey(Date.now()))};}
function doneDuty(c,u,d){const x=all('Duties').find(y=>y.company===c.id&&y.id===d.id&&(y.staff===u.u||y.captain===u.u));
 if(!x)throw new Error('not_found');upd('Duties',x._row,{done:d.done===0?0:1});return{ok:true};}
function me(c,u,d){
 const usr=all('Users').find(x=>x.company===c.id&&x.userId===u.u),b=all('Branches').find(x=>x.company===c.id&&x.id===usr.branch);
 return{ok:true,user:{userId:usr.userId,name:usr.name,role:usr.role},company:{name:c.name,code:c.code},
  branch:b?{id:b.id,name:b.name,city:b.city,wifi:wf(b.wifi).map(String),shift:fmtShift(b.shift)}:null};
}
const ACT={
 dashboard:[['owner'],dashboard],saveBranch:[['owner'],saveBranch],delBranch:[['owner'],delBranch],setBackup:[['owner'],setBackup],
 report:[['owner'],(c)=>({ok:true,text:buildReport(c,dayKey(Date.now()))})],
 addUser:[['owner','captain'],addUser],manageUser:[['owner','captain'],manageUser],
 team:[['captain'],team],assignDuty:[['captain'],assignDuty],
 myDuties:[['staff'],myDuties],doneDuty:[['staff','captain'],doneDuty],
 me:[['owner','captain','staff'],me],heartbeat:[['staff'],heartbeat]
};
// ---------- nightly WhatsApp report ----------
function buildReport(c,day){
 const brs=all('Branches').filter(b=>b.company===c.id).sort((a,b)=>String(a.city).localeCompare(String(b.city)));
 const us=all('Users').filter(x=>x.company===c.id&&x.role==='staff'&&Number(x.active)!==0);
 const att=all('Attendance').filter(a=>a.company===c.id&&Number(a.day)===day);
 const logs=all('Logs').filter(l=>l.company===c.id&&dayKey(Number(l.back))===day);
 const du=all('Duties').filter(x=>x.company===c.id&&Number(x.day)===day);
 let city='',txt=`*${c.name} - Daily Report* (${day})\n`;
 brs.forEach(b=>{
  if(b.city!==city){city=b.city;txt+=`\n=== ${city} ===\n`;}
  const tot=us.filter(x=>x.branch===b.id).length,a=att.filter(x=>x.branch===b.id),late=a.filter(x=>Number(x.late)).length;
  const g={};logs.filter(l=>l.branch===b.name).forEach(l=>{const k=l.staff+'|'+l.captain;g[k]=(g[k]||0)+(Number(l.minutes)||0);});
  const aisles={};du.filter(x=>x.branch===b.id).forEach(x=>{const k=x.aisle;aisles[k]=aisles[k]||[0,0];aisles[k][1]++;if(Number(x.done))aisles[k][0]++;});
  txt+=`\n*${b.name}*\nAttendance: Present ${a.length} / Absent ${Math.max(tot-a.length,0)} / Late ${late}\nGhost-duty audit:\n`+
   (Object.keys(g).map(k=>{const [s,cp]=k.split('|');return `- ${s} (Captain ${cp}): ${g[k]} min out`;}).join('\n')||'- none')+
   `\nTask completion:\n`+(Object.keys(aisles).map(k=>`- ${k}: ${Math.round(aisles[k][0]*100/aisles[k][1])}%`).join('\n')||'- none')+'\n';});
 return txt;
}
function nightlyReport(){const day=dayKey(Date.now());
 all('Companies').forEach(c=>{if(subState(c).allowed&&c.wa)notify(c.wa,buildReport(c,day));});}
/** Needs script properties WA_TOKEN + WA_PHONE_ID (Meta WhatsApp Cloud API). Free-text works only inside a 24h chat window;
 *  for automatic nightly messages register an approved message template. Without them, text goes to the execution log. */
function notify(to,text){
 const tok=P.getProperty('WA_TOKEN'),id=P.getProperty('WA_PHONE_ID');
 if(!to||!tok||!id){console.log('[WhatsApp not configured] to='+to+'\n'+text);return false;}
 const r=UrlFetchApp.fetch('https://graph.facebook.com/v19.0/'+id+'/messages',{method:'post',contentType:'application/json',
  headers:{Authorization:'Bearer '+tok},muteHttpExceptions:true,
  payload:JSON.stringify({messaging_product:'whatsapp',to:String(to),type:'text',text:{body:text}})});
 return r.getResponseCode()<300;
}
