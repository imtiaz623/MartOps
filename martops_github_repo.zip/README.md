# MartOps

- `lib/`, `pubspec.yaml` : Flutter app (Owner / Captain / Staff)
- `web/index.html`       : owner web panel (Vercel: Root Directory = web)
- `backend/Code.gs`      : Google Apps Script backend
- `.github/workflows/build-apk.yml` : GitHub par APK build

APK: repo ke Actions tab > Build APK > Run workflow > khatam hone par Artifacts se `martops-apk` download karo.
Pehle `lib/api.dart` mein `kApiUrl` set karo (ya repo secret `API_URL` banao).
